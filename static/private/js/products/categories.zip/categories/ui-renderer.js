// static/private/js/products/categories/ui-renderer.js

import { Row } from './components/row.js';
import { Card } from './components/card.js';

export class UIRenderer {
  constructor(elements, departmentSlug) {
    this.elements = elements;
    this.departmentSlug = departmentSlug;
    this.initialSkeleton = document.getElementById('initial-skeleton');
  }

  hideInitialSkeleton() {
    if (this.initialSkeleton) {
      this.initialSkeleton.classList.add('hidden');
    }
    if (this.elements.appContent) {
      this.elements.appContent.classList.remove('hidden');
    }
  }

  showState(state) {
    const { appContent, noPermissionState, loadingContainer, container, emptyState, errorState } = this.elements;
    
    if (this.initialSkeleton && !this.initialSkeleton.classList.contains('hidden')) {
      this.hideInitialSkeleton();
    }
    
    [appContent, noPermissionState, loadingContainer, container, emptyState, errorState].forEach(el => {
      el?.classList.add('hidden');
    });
    
    switch (state) {
      case 'loading':
        appContent?.classList.remove('hidden');
        loadingContainer?.classList.remove('hidden');
        break;
      case 'data':
        appContent?.classList.remove('hidden');
        container?.classList.remove('hidden');
        break;
      case 'empty':
        appContent?.classList.remove('hidden');
        emptyState?.classList.remove('hidden');
        break;
      case 'error':
        appContent?.classList.remove('hidden');
        errorState?.classList.remove('hidden');
        break;
      case 'no-permission':
        noPermissionState?.classList.remove('hidden');
        break;
    }
    
    this.refreshIcons();
  }

  render(data, permissions, eventHandlers) {
    const { tableBody, cardsContainer } = this.elements;
    
    if (!tableBody || !cardsContainer) return;
    
    tableBody.innerHTML = '';
    cardsContainer.innerHTML = '';
    
    data.forEach(item => {
      // Pasar departmentSlug a los componentes
      const row = Row.create(item, permissions, eventHandlers, this.departmentSlug);
      const card = Card.create(item, permissions, eventHandlers, this.departmentSlug);
      
      tableBody.appendChild(row);
      cardsContainer.appendChild(card);
    });
    
    this.refreshIcons();
  }

  setErrorMessage(message) {
    const { errorMessage } = this.elements;
    if (errorMessage) {
      errorMessage.textContent = message;
    }
  }

  refreshIcons() {
    window.lucide?.createIcons?.();
  }
}